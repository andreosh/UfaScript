<?php   defined('_JEXEC') or die;  ?>
<ol class="menu-ol"><div class="menu1-container">
<?php 
foreach ($list as $i => &$item)   {
    $curent = FALSE;    if ($item->id == $active_id) {	$curent = TRUE; 	}		echo '<li>';	
	if ($curent) {	echo "<a href='".$item->flink."' class='now menu1-block'>".$item->title."</a>"; 	}  else {
		echo "<a href='".$item->flink."' class='menu menu1-block'>".$item->title."</a>"; }     echo '</li>'; 
}   ?>
</div></ol>


